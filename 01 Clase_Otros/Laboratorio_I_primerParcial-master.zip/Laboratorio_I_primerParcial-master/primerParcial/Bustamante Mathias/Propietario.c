#include "propietarioAutomovil.h"


void ePropietario_hardCode(ePropietario* pPropietario)
{
    int i;

    int hardcode_ID[5]= {1,2,3,4,5};
    char hardcode_NAME[5][SIZE_NAME]= {"Juan","Carlos", "Belen", "Mathias", "Adrian"};
    char hardcode_DIRECCION[5][SIZE_DIRECCION]= {"Bautista 154","Zarate 258", "Damiano 125", "Bustamante 784", "Lopez 114"};
    char hardcode_TARJETACREDITO[5][SIZE_TARJETACREDITO]= {"5485-6587-5214-5525","1254-9856-7845-5698", "1597-4587-9536-7418", "1256-8547-9658-5268", "4598-7845-5284-6935"};

    for(i=0; i<5; i++)
    {
        pPropietario[i].idPropietario=hardcode_ID[i];
        strcpy(pPropietario[i].name, hardcode_NAME[i]);
        strcpy(pPropietario[i].direccion, hardcode_DIRECCION[i]);
        strcpy(pPropietario[i].tarjetaCredito, hardcode_TARJETACREDITO[i]);
        pPropietario[i].isEmpty=OCUPADO;
    }
}

void ePropietario_inicializar(ePropietario* pPropietario, int SIZEARRAY)
{
    int i;
    for(i=0; i<SIZEARRAY; i++)
    {
        pPropietario[i].isEmpty=LIBRE;
    }
}

int ePropietario_buscarEspacioLibre(ePropietario* pPropietario, int SIZEARRAY)
{
    int indiceVectorLibre=-1;
    int i;

    for(i=0; i<SIZEARRAY; i++)
    {
        if(pPropietario[i].isEmpty==LIBRE)
        {
            indiceVectorLibre=i;
            break;
        }

    }

    return indiceVectorLibre;
}

ePropietario getPropietario()
{
    ePropietario pPropietario;
    char auxName[SIZE_NAME];
    char auxLastName[SIZE_NAME];
    char buffer[SIZE_NAME];

    getName(auxName, 30);
    getLastName(auxLastName, 30);

    strcpy(buffer, auxLastName);
    strcat(buffer, ", ");
    strcat(buffer, auxName);

    strcpy(pPropietario.name, buffer);

    getDireccion(pPropietario.direccion, SIZE_DIRECCION);
    getTarjetaCredito("INGRESE TARJETA DE CREDITO: ", pPropietario.tarjetaCredito);

    return pPropietario;
}

int altaPropietario(ePropietario* pPropietario, int SIZEARRAY)
{
    int index;
    int founded=0;

    index=ePropietario_buscarEspacioLibre(pPropietario, SIZEARRAY);

    if(index!=-1)
    {
        system("cls");
        puts("\nINGRESE DATOS DEL PROPIETARIO\n\n");

        pPropietario[index]=getPropietario();
        pPropietario[index].isEmpty=OCUPADO;
        pPropietario[index].idPropietario=index+1;

        founded=1;
    }
    return founded;
}

int cantidadPropietarioTrueFalse(ePropietario* pPropietario, int SIZEARRAY)
{

    int cantPropietario=0;
    int i;

    for(i=0; i<SIZEARRAY; i++)
    {
        if(pPropietario[i].isEmpty==OCUPADO)
        {
            cantPropietario=1;
            break;
        }
    }

    return cantPropietario;
}

int modificarPropietario(ePropietario* pPropietario, int SIZEARRAY)
{
    int flag=0;
    int flagDos=0;
    int eID;
    int i;
    int founded=0;
    int verificar=cantidadPropietarioTrueFalse(pPropietario, SIZEARRAY);
    int cancelada=0;

    if (verificar==0)
    {
        system("cls");
        puts("\n[ERROR] NINGUN PROPIETARIO PARA MODIFICAR\n\n");
    }

    while(verificar==1&&flag==0)
    {
        flag=1;

        system("cls");
        puts("\nMODIFICAR TARJETA PROPIETARIO\n\n");
        puts("[ID]\t[NOMBRE PROPIETARIO]\n");
        puts("0\t[SALIR]\n");
        for(i=0; i<SIZEARRAY; i++)
        {
            if(pPropietario[i].isEmpty==OCUPADO)
            {
                printf("%d\t%s\n",pPropietario[i].idPropietario, pPropietario[i].name);

            }
        }

        eID=getInt("\nINGRESE ID A MODIFICAR: ");

        system("cls");
        printf("\nID: N%c %d\n", 248, eID);

        for(i=0; i<SIZEARRAY; i++)
        {
            if(pPropietario[i].idPropietario==eID&&pPropietario[i].isEmpty==OCUPADO)
            {
                puts("\n[EXITO] EMPLEADO ENCONTRADO\n");
                switch(subMenuUno())

                {
                case 1:
                    system("cls");
                    getTarjetaCredito("INGRESE NUEVO NUMERO DE TARJETA: ", pPropietario[i].tarjetaCredito);
                    founded=1;
                    break;
                case 0:
                    puts("\n[TARJETA DE CREDITO NO MODIFICADA]\n");
                    flagDos=1;
                    break;

                default:
                    puts("\n[ERROR] OPCION NO VALIDA\n");
                    flagDos=1;
                    break;
                }
            }
            else if(eID==0)
            {
                cancelada=1;
                system("cls");
                puts("\n[MODIFICACION CANCELADA]\n");
                system("pause");
                break;
            }

        }
        if (founded==0&&flagDos==0&&cancelada==0)
        {
            puts("\n[ERROR] ID DE PROPIETARIO NO ENCONTRADO\n");
            break;
        }
    }
    return founded;
}

void ordenarAlfabeticamente(ePropietario* pPropietario, int SIZEARRAY)
{

    int i;
    int j;
    ePropietario auxPropietario;

    for(i=0; i<SIZEARRAY-1; i++)
    {
        for (j=i+1; j<SIZEARRAY; j++)
        {
            if(pPropietario[i].isEmpty==OCUPADO && pPropietario[j].isEmpty==OCUPADO)
            {
                if(strcmp(pPropietario[i].name, pPropietario[j].name)>0)
                {
                    auxPropietario=pPropietario[i];
                    pPropietario[i]=pPropietario[j];
                    pPropietario[j]=auxPropietario;
                }
            }

        }
    }
}

int listarPropietarioName(ePropietario* pPropietario, int SIZEARRAY)
{
    int retorno=0;
    int i;
    puts("[ID]\t[NOMBRE PROPIETARIO]\n");

    ordenarAlfabeticamente(pPropietario, SIZEARRAY);

    /**IMPRIME LA LISTA ORDENADA POR NOMBRE*/

    for(i=0; i<SIZEARRAY; i++)
    {
        if(pPropietario[i].isEmpty==OCUPADO)
        {
            printf("%c %d\t%s\n", 250, pPropietario[i].idPropietario, pPropietario[i].name);
            retorno=1;
        }
    }

    /**VUELVE A ORDENAR EL ARRAY POR ID*/

    ordenarID(pPropietario, SIZEARRAY);

    return retorno;
}

void ordenarID(ePropietario* pPropietario, int SIZEARRAY)
{
    int i;
    int j;
    ePropietario auxPropietario;

    for(i=0; i<SIZEARRAY-1; i++)
    {
        for (j=i+1; j<SIZEARRAY; j++)
        {
            if(pPropietario[i].isEmpty==OCUPADO && pPropietario[j].isEmpty==OCUPADO)
            {
                if(pPropietario[i].idPropietario>pPropietario[j].idPropietario)
                {
                    auxPropietario=pPropietario[i];
                    pPropietario[i]=pPropietario[j];
                    pPropietario[j]=auxPropietario;
                }
            }

        }
    }


}

void listarPropietarios(ePropietario* pPropietario, int SIZEARRAY)
{
    int i;

    puts("[ID]\t[NOMBRE PROPIETARIO]\n");

    for(i=0; i<SIZEARRAY; i++)
    {
        if(pPropietario[i].isEmpty==OCUPADO)
        {
            printf("  %d\t%s\n", pPropietario[i].idPropietario, pPropietario[i].name);
        }
    }
}

