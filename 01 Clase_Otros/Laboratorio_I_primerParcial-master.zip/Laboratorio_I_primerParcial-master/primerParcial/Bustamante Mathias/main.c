#include "propietarioAutomovil.h"



int main()
{

    /**INICIALIZAR PROPIETARIO-HARDCODE*/
    ePropietario pPropietario[ARRAYSIZE];
    ePropietario_inicializar(pPropietario,ARRAYSIZE);
    ePropietario_hardCode(pPropietario);

    /**INICIALIZAR AUTOMOVIL-HARDCODEO*/
    eAutomovil pAutomovil[ARRAYSIZE];
    eAutomovil_inicializar(pAutomovil,ARRAYSIZE);
    eAutomovil_hardCode(pAutomovil);

    /**INICIALIZA STRUCT DE RECAUDO*/
    eRecaudo pRecaudo[ARRAY_RECAUDO];
    eRecaudo_inicializar(pRecaudo);

    int opcion;

    do
    {

        switch(opcion=getMenu())
        {
        case 0:

            system("cls");

            if(!getSalida("\n\n - SEGURO QUE DESEA SALIR? [S]SALIR [N]CANCELAR: "))
            {
                opcion=1;
            }
            break;
        case 1:
            if(altaPropietario(pPropietario, ARRAYSIZE))
            {
                puts("\n[CARGA EXITOSA DE PROPIETARIO] ");
                system("pause");
                system("cls");
            }
            else
            {
                puts("\n[FALLA EN LA CARGA DE PROPIETARIO] ");
                system("pause");
                system("cls");
            }
            break;
        case 2:
            if(modificarPropietario(pPropietario, ARRAYSIZE))
            {
                puts("[MODIFICACION EXITOSA] ");
                system("pause");
                system("cls");
            }
            else
            {
                puts("\n[FALLA EN LA MODIFICACION] ");
                system("pause");
                system("cls");
            }
            break;
        case 3:
            if(bajaPropietario(pPropietario, pAutomovil, pRecaudo, ARRAYSIZE))
            {
                system("pause");
                system("cls");
            }
            break;
        case 4:
            system("cls");
            if(cantidadPropietarioTrueFalse(pPropietario, ARRAYSIZE))
            {
                if(listarPropietarioName(pPropietario, ARRAYSIZE))
                {
                    puts("\n[LISTADO EXITOSO] ");
                    system("pause");
                    system("cls");
                }
                else
                {
                    puts("\n[FALLA EN EL LISTADO] ");
                    system("pause");
                    system("cls");
                }
            }
            else
            {
                puts("\n[SIN PROPIETARIOS PARA LISTAR] ");
                system("pause");
                system("cls");
            }
            break;
        case 5:
            if(altaAutomovil(pAutomovil, pPropietario, ARRAYSIZE))
            {
                puts("\n[CARGA DE AUTOMOVIL EXITOSA] ");
                system("pause");
            }
            else
            {
                puts("\n[FALLA EN CARGA DE AUTOMOVIL] ");
                system("pause");
            }
            break;
        case 6:
            if(egresoAutomovil(pAutomovil, pPropietario, pRecaudo, ARRAYSIZE))
            {
                puts("[EGRESO DE AUTOMOVIL CON EXITO] ");
                system("pause");
                system("cls");
            }
            else
            {
                puts("[SE CANCELO EGRESO DEL AUTOMOVIL] ");
                system("pause");
                system("cls");
            }
            break;
        case 7:
            if(cantidadAutomoviles(pAutomovil,ARRAYSIZE)>0)
            {
                system("cls");
                puts("\n[AUTOMOVILES ESTACIONADOS]\n");
                listarAutomoviles(pAutomovil, pPropietario, ARRAYSIZE);
                puts("\n");
                system("pause");
            }
            else
            {
                system("cls");
                puts("\n[SIN AUTOMOVILES ESTACIONADOS]\n\n");
                system("pause");
                system("cls");
            }
            break;
        case 8:
            if(pRecaudo->recaudoTotal>0)
            {
                recaudoTotal(pRecaudo);
            }
            else
            {
                puts("\n[SIN RECAUDOS]\n");
                system("pause");
                system("cls");
            }
            break;
        case 9:
            if(pRecaudo->recaudoTotal>0)
            {
                recaudoMarcas(pRecaudo);
            }
            else
            {
                puts("\n[SIN RECAUDOS]\n");
                system("pause");
                system("cls");
            }
            break;
        case 10:
            system("cls");
            if(infoPropietario_Automoviles(pAutomovil, pPropietario, ARRAYSIZE))
            {
                system("pause");
                system("cls");
            }
            else
            {
                puts("\n[ID DE PROPIETARIO INCORRECTO]\n");
                system("pause");
                system("cls");
            }
            break;
        case 11:
            system("cls");
            if(infoPropietario_AutomovilesAudi(pAutomovil, pPropietario, ARRAYSIZE))
            {
                system("pause");
                system("cls");
            }
            else
            {
                puts("\n[SIN PROPIETARIOS CON AUTOMOVILES ESTACIONADOS DE MARCA AUDI]\n");
                system("pause");
                system("cls");
            }

            break;
        case 12:
            if(cantidadAutomoviles(pAutomovil,ARRAYSIZE)>0)
            {
                system("cls");
                puts("\n[AUTOMOVILES ESTACIONADOS ORDENADOS POR PATENTE]\n");
                listarAutomoviles_patente(pAutomovil, pPropietario, ARRAYSIZE);
                puts("\n");
                system("pause");
            }
            else
            {
                system("cls");
                puts("\n[SIN AUTOMOVILES ESTACIONADOS]\n\n");
                system("pause");
                system("cls");
            }
            break;
        default:
            puts("\n[NO ES UNA OPCION VALIDA]\n");
            system("pause");
            system("cls");
            break;
        }



    }
    while(opcion!=0);

    return 0;
}
