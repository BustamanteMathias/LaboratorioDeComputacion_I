#include "propietarioAutomovil.h"
#define PRECIO_ALPHAROMEO 150
#define PRECIO_FERRARI 175
#define PRECIO_AUDI 200
#define PRECIO_OTRO 250

void eRecaudo_inicializar(eRecaudo* pRecaudo)
{
    pRecaudo->recaudoTotal=0;
    pRecaudo->recaudoOtros=0;
    pRecaudo->recaudoAlphaRomeo=0;
    pRecaudo->recaudoFerrari=0;
    pRecaudo->recaudoAudi=0;
}

int calcularImporte(int MARCA, eRecaudo* pRecaudo)
{
    int importe=0;
    int horasEstadia;

    switch(MARCA)
    {
    case 0:

        horasEstadia=devolverHorasEstadia();
        importe=horasEstadia*PRECIO_OTRO;

        /**RECAUDO OTRO*/
        pRecaudo->recaudoOtros=pRecaudo->recaudoOtros+importe;
        break;

    case 1:
        horasEstadia=devolverHorasEstadia();
        importe=horasEstadia*PRECIO_ALPHAROMEO;

        /**RECAUDO DE ALPHA ROMEO*/
        pRecaudo->recaudoAlphaRomeo=pRecaudo->recaudoAlphaRomeo+importe;
        break;

    case 2:

        horasEstadia=devolverHorasEstadia();
        importe=horasEstadia*PRECIO_FERRARI;

        /**RECAUDO DE FERRARI*/
        pRecaudo->recaudoFerrari=pRecaudo->recaudoFerrari+importe;
        break;

    case 3:

        horasEstadia=devolverHorasEstadia();
        importe=horasEstadia*PRECIO_AUDI;

        /**RECAUDO DE AUDI*/
        pRecaudo->recaudoAudi=pRecaudo->recaudoAudi+importe;
        break;
    }

    /** RECAUDO TOTAL*/
    pRecaudo->recaudoTotal=pRecaudo->recaudoTotal+importe;

    return importe;
}

int calcularImporte_horasEstadia(int MARCA, int horasEstadia)
{
    int importe=0;

    switch(MARCA)
    {
    case 0:
        importe=horasEstadia*PRECIO_OTRO;
        break;
    case 1:
        importe=horasEstadia*PRECIO_ALPHAROMEO;
        break;
    case 2:
        importe=horasEstadia*PRECIO_FERRARI;
        break;
    case 3:
        importe=horasEstadia*PRECIO_AUDI;
        break;
    }

    return importe;
}

void bajaAutomovilEstacionadoPropietario(eAutomovil* pAutomovil, int SIZEARRAY, int IDPropietario)
{
    int i;

    for(i=0; i<SIZEARRAY; i++)
    {
        if(pAutomovil[i].idPropietarioAutomovil==IDPropietario)
        {
            pAutomovil[i].isEmpty=LIBRE;
        }
    }
}

int bajaPropietario(ePropietario* pPropietario, eAutomovil* pAutomovil, eRecaudo* pRecaudo, int SIZEARRAY)
{
    int flag=0;
    int eID;
    int i;
    int founded=0;
    int verificar=cantidadPropietarioTrueFalse(pPropietario, SIZEARRAY);
    int acumAutos=0;
    int importeTotal=0;
    int auxCalcularImporte;
    int j;
    int continuar;

    if (verificar==0)
    {
        system("cls");
        puts("\n[ERROR] NINGUN PROPIETARIO PARA DAR DE BAJA\n\n");
    }


    while(verificar==1&&flag==0)
    {
        flag=1;
        system("cls");
        puts("\nBAJA PROPIETARIO\n\n");

        puts("[ID]\t[NOMBRE PROPIETARIO]\n");
        puts("0\t[SALIR]\n");

        for(i=0; i<SIZEARRAY; i++)
        {
            if(pPropietario[i].isEmpty==OCUPADO)
            {
                printf("%d\t%s\n",pPropietario[i].idPropietario, pPropietario[i].name);
            }
        }

        puts(" ");
        eID=getInt("INGRESE ID A DAR DE BAJA: ");

        system("cls");
        printf("\n\nID: N%c %d\n", 248, eID);

        for(i=0; i<SIZEARRAY; i++)
        {
            if(pPropietario[i].idPropietario==eID&&pPropietario[i].isEmpty==OCUPADO)
            {
                puts("\n[EXITO] PROPIETARIO ENCONTRADO\n");
                continuar=getContinuar("CONFIRMAR DAR DE BAJA. [S]CONFIRMAR - [N]CANCELAR: ");

                if(continuar)
                {
                    system("cls");
                    for(j=0; j<ARRAYSIZE; j++)
                    {
                        if(pAutomovil[j].idPropietarioAutomovil==eID&&pAutomovil[j].isEmpty==OCUPADO)
                        {
                            founded=1;
                            acumAutos++;
                            auxCalcularImporte=calcularImporte(pAutomovil[j].marca, pRecaudo);
                            importeTotal=importeTotal+auxCalcularImporte;

                            printf("[AUTOMOVIL %d] IMPORTE A PAGAR: %d\n", acumAutos, auxCalcularImporte);
                        }

                    }

                    if(acumAutos==0)
                    {
                        founded=1;
                        printf("\n[SIN AUTOMOVIL ESTACIONADOS]\n");
                    }
                    else if(acumAutos>0)
                    {
                        printf("\n\nCANTIDAD DE AUTOMOVILES ESTACIONADOS: %d\nTOTAL A PAGAR: %d\n\n", acumAutos, importeTotal);
                        bajaAutomovilEstacionadoPropietario(pAutomovil, SIZEARRAY, eID);
                    }

                    pPropietario[i].isEmpty=LIBRE;
                    puts("\n[BAJA EXITOSA]");
                }
            }
            else
            {
                founded=2;
            }
        }

        if(founded!=1)
        {
            puts("\n[ERROR] PROPIETARIO NO EXISTE O BAJA CANCELADA");
            founded=1;
        }

        if (founded==0&&eID==0)
        {
            puts("\nBAJA CANCELADA\n");
            system("pause");
            founded=0;
        }
        else if(eID==0)
        {
            founded=0;
            system("cls");
            puts("\n[BAJA CANCELADA] ");
            system("pause");
        }
    }

    return founded;
}

eAutomovil getAutomovil(ePropietario* pPropietario, int SIZEARRAY)
{
    eAutomovil pAutomovil;
    int IDpropietario;
    int i;
    int flag=0;
    int opcion;
    int marca=3;
    char auxMarca[4][12]= {"ALPHA ROMEO", "FERRARI", "AUDI", "OTRO"};
    getPatente(pAutomovil.patente, SIZE_PATENTE);

    opcion=subMenuDos();

    switch(opcion)
    {
    case 1:
        pAutomovil.marca=ALPHA_ROMEO;
        marca=0;
        break;
    case 2:
        pAutomovil.marca=FERRARI;
        marca=1;
        break;
    case 3:
        pAutomovil.marca=AUDI;
        marca=2;
        break;
    case 4:
        pAutomovil.marca=OTRO;
        break;
    }

    do
    {
        system("cls");

        printf("[SELECCIONE PROPIETARIO DE AUTOMOVIL]\n\n");
        printf("[ID]\t[NOMBRE Y APELLIDO]\n\n");
        for(i=0; i<SIZEARRAY; i++)
        {
            if(pPropietario[i].isEmpty==OCUPADO)
            {
                printf("%d\t%s\n", pPropietario[i].idPropietario, pPropietario[i].name);
            }

        }
        IDpropietario=getInt("\nID: ");

        for(i=0; i<SIZEARRAY; i++)
        {

            if(pPropietario[i].idPropietario==IDpropietario&&pPropietario[i].isEmpty==OCUPADO)
            {
                pAutomovil.idPropietarioAutomovil=pPropietario[i].idPropietario;
                flag=1;
                printf("\n[EXITO]\n\nPROPIETARIO DE AUTOMOVIL: %s\nPATENTE: %s\nMARCA: %s\n\n", pPropietario[i].name, pAutomovil.patente, auxMarca[marca]);
                break;
            }
            else if(i==SIZEARRAY-1&&flag==0)
            {
                printf("\n[ID INCORRECTO] PROPIETARIO NO ENCONTRADO. SELECCIONE ID DEL LISTADO\n\n");
                system("pause");
                system("cls");
            }
        }
    }
    while(flag==0);


    return pAutomovil;
}

int altaAutomovil(eAutomovil* pAutomovil,ePropietario* pPropietario, int SIZEARRAY)
{
    int index;
    int founded=0;

    index=eAutomovil_buscarEspacioLibre(pAutomovil, SIZEARRAY);

    if(index!=-1)
    {
        system("cls");
        puts("\nINGRESE DATOS DEL AUTOMOVIL\n\n");

        pAutomovil[index]=getAutomovil(pPropietario, SIZEARRAY);
        pAutomovil[index].isEmpty=OCUPADO;
        pAutomovil[index].idAutomovil=index+1;

        founded=1;
    }

    return founded;
}

void listarAutomoviles(eAutomovil* pAutomovil, ePropietario* pPropietario, int SIZEARRAY)
{
    int i;
    int auxMarca;

    printf("[ID]\t[MARCA AOTOMOVIL]\t[NOMBRE PRIPETARIO]\n\n");
    for(i=0; i<SIZEARRAY; i++)
    {
        if(pAutomovil[i].isEmpty==OCUPADO)
        {
            auxMarca=pAutomovil[i].marca;

            switch(auxMarca)
            {
            case 0:
                printf("%d\t%s\t\t\t%s\n", pAutomovil[i].idAutomovil, "OTRO", pPropietario[i].name);
                break;
            case 1:
                printf("%d\t%s\t\t%s\n", pAutomovil[i].idAutomovil, "ALPHA ROMEO", pPropietario[i].name);
                break;
            case 2:
                printf("%d\t%s\t\t\t%s\n", pAutomovil[i].idAutomovil, "FERRARI", pPropietario[i].name);
                break;
            case 3:
                printf("%d\t%s\t\t\t%s\n", pAutomovil[i].idAutomovil, "AUDI", pPropietario[i].name);
                break;
            }
        }
    }
}

void imprimirTicket(eAutomovil* pAutomovil, ePropietario* pPropietario, eRecaudo* pRecaudo, int idAutomovil, int SIZEARRAY)
{
    ePropietario auxPropietario;
    eAutomovil auxAutomovil;
    auxAutomovil.marca=0;
    int idPropietario;
    int auxMarca=NULL;
    int i;
    int horasEstadia;
    int importeEstadia;

    for(i=0; i<SIZEARRAY; i++)
    {
        if(pAutomovil[i].idAutomovil==idAutomovil && pAutomovil[i].isEmpty==OCUPADO)
        {
            auxAutomovil=pAutomovil[i];
            break;
        }
    }

    idPropietario=auxAutomovil.idPropietarioAutomovil;

    for(i=0; i<SIZEARRAY; i++)
    {
        if(pPropietario[i].idPropietario==idPropietario && pPropietario[i].isEmpty==OCUPADO)
        {
            auxPropietario=pPropietario[i];
            break;
        }
    }

    auxMarca=auxAutomovil.marca;

    horasEstadia=devolverHorasEstadia();
    importeEstadia=calcularImporte_horasEstadia(auxMarca, horasEstadia);

    switch(auxMarca)
    {
    case 0:
        /**OTRO*/
        system("cls");
        puts("\n");
        printf("***********************************************************\n");
        printf("*** T I C K E T : E G R E S O   D E   A U T O M O V I L ***\n");
        printf("***********************************************************\n\n");
        printf("   MARCA: OTRO\n\n");
        printf("   PATENTE: %s\n\n", auxAutomovil.patente);
        printf("   PROPIETARIO: %s\n\n\n", auxPropietario.name);
        printf("   HORAS ESTACIONADO: %d\n\n", horasEstadia);
        printf("   COSTE POR HORA: %c %d.00\n\n\n", 36, PRECIO_OTRO);
        printf(" %c IMPORTE FINAL A PAGAR: %c %d.00\n\n", 254, 36, importeEstadia);
        printf("***********************************************************\n\n");

        /**RECAUDO DE OTRAS MARCAS*/
        pRecaudo->recaudoOtros=pRecaudo->recaudoOtros+importeEstadia;
        break;

    case 1:
        /**ALPHA ROMEO*/
        system("cls");
        puts("\n");
        printf("***********************************************************\n");
        printf("*** T I C K E T : E G R E S O   D E   A U T O M O V I L ***\n");
        printf("***********************************************************\n\n");
        printf("   MARCA: ALPHA ROMEO\n\n");
        printf("   PATENTE: %s\n\n", auxAutomovil.patente);
        printf("   PROPIETARIO: %s\n\n\n", auxPropietario.name);
        printf("   HORAS ESTACIONADO: %d\n\n", horasEstadia);
        printf("   COSTE POR HORA: %c %d.00\n\n\n", 36, PRECIO_ALPHAROMEO);
        printf(" %c IMPORTE FINAL A PAGAR: %c %d.00\n\n", 254, 36, importeEstadia);
        printf("***********************************************************\n\n");

        /**RECAUDO DE ALPHA ROMEO*/
        pRecaudo->recaudoAlphaRomeo=pRecaudo->recaudoAlphaRomeo+importeEstadia;
        break;

    case 2:
        /**FERRARI*/
        system("cls");
        puts("\n");
        printf("***********************************************************\n");
        printf("*** T I C K E T : E G R E S O   D E   A U T O M O V I L ***\n");
        printf("***********************************************************\n\n");
        printf("   MARCA: FERRARI\n\n");
        printf("   PATENTE: %s\n\n", auxAutomovil.patente);
        printf("   PROPIETARIO: %s\n\n\n", auxPropietario.name);
        printf("   HORAS ESTACIONADO: %d\n\n", horasEstadia);
        printf("   COSTE POR HORA: %c %d.00\n\n\n", 36, PRECIO_FERRARI);
        printf(" %c IMPORTE FINAL A PAGAR: %c %d.00\n\n", 254, 36, importeEstadia);
        printf("***********************************************************\n\n");

        /**RECAUDO DE FERRARI*/
        pRecaudo->recaudoFerrari=pRecaudo->recaudoFerrari+importeEstadia;
        break;

    case 3:
        /**AUDI*/
        system("cls");
        puts("\n");
        printf("***********************************************************\n");
        printf("*** T I C K E T : E G R E S O   D E   A U T O M O V I L ***\n");
        printf("***********************************************************\n\n");
        printf("   MARCA: ALPHA ROMEO\n\n");
        printf("   PATENTE: %s\n\n", auxAutomovil.patente);
        printf("   PROPIETARIO: %s\n\n\n", auxPropietario.name);
        printf("   HORAS ESTACIONADO: %d\n\n", horasEstadia);
        printf("   COSTE POR HORA: %c %d.00\n\n\n", 36, PRECIO_AUDI);
        printf(" %c IMPORTE FINAL A PAGAR: %c %d.00\n\n", 254, 36, importeEstadia);
        printf("***********************************************************\n\n");

        /**RECAUDO DE AUDI*/
        pRecaudo->recaudoAudi=pRecaudo->recaudoAudi+importeEstadia;
        break;

    }

    /** RECAUDO TOTAL*/
    pRecaudo->recaudoTotal=pRecaudo->recaudoTotal+importeEstadia;
}

int egresoAutomovil(eAutomovil* pAutomovil, ePropietario* pPropietario, eRecaudo* pRecaudo, int SIZEARRAY)
{
    int retorno=1;
    int i;
    int getId;
    int flag=0;

    system("cls");
    puts("EGRESO DE AUTOMOVIL\n");
    puts("0\t[SALIR]\n");
    listarAutomoviles(pAutomovil, pPropietario, SIZEARRAY);

    getId=getInt("\n[SELECCIONE ID DE AUTOMOVIL PARA DAR EGRESO]: ");
    if(getId==0)
    {
        retorno=0;
    }
    else
    {
        for(i=0; i<SIZEARRAY; i++)
        {
            if(pAutomovil[i].idAutomovil==getId && pAutomovil[i].isEmpty==OCUPADO)
            {
                flag=1;
                if(getContinuar("SEGURO QUE DESEA DAR EGRESO? [S] CONTINUAR [N] CANCELAR: "))
                {
                    /** GENERAR TICKET Y EGRESO*/
                    imprimirTicket(pAutomovil, pPropietario, pRecaudo, getId, SIZEARRAY);
                    pAutomovil[i].isEmpty=LIBRE;
                    retorno=1;
                }
                else
                {
                    /**CANCELO EL EGRESO*/
                    flag=2;
                }
            }
        }
    }

    if(flag==0&&retorno==1)
    {
        printf("\nENTRADA DE ID INVALIDA\n\n");
        system("pause");
    }
    else if(flag==2)
    {
        printf("\nEGRESO CANCELADO\n\n");
        system("pause");
    }

    return retorno;
}

void recaudoTotal(eRecaudo* pRecaudo)
{
    system("cls");
    puts("\n[RECAUDO TOTAL]\n");
    printf("RECAUDO TOTAL DEL ESTACIONAMIENTO: %c %d\n", 36, pRecaudo->recaudoTotal);
    puts("\n");
    system("pause");
}

void recaudoMarcas(eRecaudo* pRecaudo)
{
    system("cls");
    puts("\n[RECAUDOS]\n");
    printf("RECAUDO OTRAS MARCAS: %c %d\n", 36, pRecaudo->recaudoOtros);
    printf("RECAUDO AUDI: %c %d\n", 36, pRecaudo->recaudoAudi);
    printf("RECAUDO FERRARI: %c %d\n", 36, pRecaudo->recaudoFerrari);
    printf("RECAUDO ALPHA ROMEO: %c %d\n", 36, pRecaudo->recaudoAlphaRomeo);
    puts("\n");
    system("pause");
}

int infoPropietario_Automoviles(eAutomovil* pAutomovil, ePropietario* pPropietario, int SIZEARRAY)
{
    int retorno=0;
    int flag=0;
    int contAutomovil=0;
    int getId;
    int i;
    int j;

    printf("[INFORMACION DE AUTOMOVILES DEL PROPIETARIO]\n");
    printf("\n\n  0\t[SALIR]\n\n");

    listarPropietarios(pPropietario, SIZEARRAY);

    getId=getInt("\nINGRESE ID: ");

    if(getId!=0)
    {
        for(i=0; i<ARRAYSIZE; i++)
        {
            if(pPropietario[i].idPropietario==getId && pPropietario[i].isEmpty==OCUPADO)
            {
                retorno=1;

                system("cls");
                printf("\n\nPROPIETARIO: %s\n\n", pPropietario[i].name);

                for(j=0; j<SIZEARRAY; j++)
                {
                    if(pAutomovil[j].idPropietarioAutomovil==getId && pAutomovil[j].isEmpty==OCUPADO)
                    {
                        flag=1;
                        contAutomovil++;

                        switch(pAutomovil[j].marca)
                        {
                        case 0:
                            printf("AUTOMOVIL %d:\tMARCA: OTRO       \tPATENTE: %s\n", contAutomovil, pAutomovil[j].patente);
                            break;
                        case 1:
                            printf("AUTOMOVIL %d:\tMARCA: ALPHA ROMEO\tPATENTE: %s\n", contAutomovil, pAutomovil[j].patente);
                            break;
                        case 2:
                            printf("AUTOMOVIL %d:\tMARCA: FERRARI    \tPATENTE: %s\n", contAutomovil, pAutomovil[j].patente);
                            break;
                        case 3:
                            printf("AUTOMOVIL %d:\tMARCA: AUDI       \tPATENTE: %s\n", contAutomovil, pAutomovil[j].patente);
                            break;
                        }

                    }
                }

            }
        }

        if(flag==0 && retorno==1)
        {
            printf("[SIN AUTOMOVILES ESTACIONADOS]\n");
        }
    }

    if(getId==0)
    {
        retorno=2;
        printf("[SALIENDO]\n");
    }

    return retorno;
}

int infoPropietario_AutomovilesAudi(eAutomovil* pAutomovil, ePropietario* pPropietario, int SIZEARRAY)
{
    int retorno=0;
    int contAutomovil=0;
    int i;
    int j;

    printf("[INFORMACION DE PROPIETARIOS AUTOMOVILES MARCA AUDI]\n\n\n");


    for(i=0; i<ARRAYSIZE; i++)
    {
        if(pPropietario[i].isEmpty==OCUPADO)
        {

            for(j=0; j<SIZEARRAY; j++)
            {
                if(pAutomovil[j].idPropietarioAutomovil==pPropietario[i].idPropietario && pAutomovil[j].isEmpty==OCUPADO && pAutomovil[j].marca==AUDI)
                {
                    contAutomovil++;
                    retorno=1;
                    printf("***********************************************************\n");
                    printf("  PROPIETARIO: %s\n", pPropietario[i].name);
                    printf("  TARJETA DE CREDITO: %s\n\n", pPropietario[i].tarjetaCredito);
                    printf("  AUTOMOVIL %d  PATENTE: %s\n", contAutomovil, pAutomovil[j].patente);
                }
            }
        }
    }
    printf("***********************************************************\n");
    return retorno;
}

void ordenarPatente(eAutomovil* pAutomovil, int SIZEARRAY)
{

    int i;
    int j;
    eAutomovil auxAutomovil;

    for(i=0; i<SIZEARRAY-1; i++)
    {
        for (j=i+1; j<SIZEARRAY; j++)
        {
            if(pAutomovil[i].isEmpty==OCUPADO && pAutomovil[j].isEmpty==OCUPADO)
            {
                if(strcmp(pAutomovil[i].patente, pAutomovil[j].patente)>0)
                {
                    auxAutomovil=pAutomovil[i];
                    pAutomovil[i]=pAutomovil[j];
                    pAutomovil[j]=auxAutomovil;
                }
            }

        }
    }


}

int listarAutomoviles_patente(eAutomovil* pAutomovil, ePropietario* pPropietario, int SIZEARRAY)
{
    int retorno=0;
    int i;
    int j;

    ordenarPatente(pAutomovil, SIZEARRAY);

    puts("[MARCA]      [PATENTE]\t[TARJETA DE CREDITO]\t[NOMBRE PROPIETARIO]\n");

    for(i=0; i<SIZEARRAY; i++)
    {
        if(pAutomovil[i].isEmpty==OCUPADO)
        {
            retorno=1;

            switch(pAutomovil[i].marca)
            {
            case 0:
                for(j=0; j<SIZEARRAY; j++)
                {
                    if(pPropietario[j].idPropietario==pAutomovil[i].idPropietarioAutomovil)
                    {
                        printf("OTRO         %s\t%s\t%s\n", pAutomovil[i].patente, pPropietario[j].tarjetaCredito, pPropietario[j].name);
                        break;
                    }
                }
                break;
            case 1:
                for(j=0; j<SIZEARRAY; j++)
                {
                    if(pPropietario[j].idPropietario==pAutomovil[i].idPropietarioAutomovil)
                    {
                        printf("ALPHA ROMEO  %s\t%s\t%s\n", pAutomovil[i].patente, pPropietario[j].tarjetaCredito, pPropietario[j].name);
                        break;
                    }
                }
                break;
            case 2:
                for(j=0; j<SIZEARRAY; j++)
                {
                    if(pPropietario[j].idPropietario==pAutomovil[i].idPropietarioAutomovil)
                    {
                        printf("FERRARI      %s\t%s\t%s\n", pAutomovil[i].patente, pPropietario[j].tarjetaCredito, pPropietario[j].name);
                        break;
                    }
                }
                break;
            case 3:
                for(j=0; j<SIZEARRAY; j++)
                {
                    if(pPropietario[j].idPropietario==pAutomovil[i].idPropietarioAutomovil)
                    {
                        printf("AUDI         %s\t%s\t%s\n", pAutomovil[i].patente, pPropietario[j].tarjetaCredito, pPropietario[j].name);
                        break;
                    }
                }
                break;
            }
        }
    }

    //ordenarID(pPropietario, SIZEARRAY);

    return retorno;
}

