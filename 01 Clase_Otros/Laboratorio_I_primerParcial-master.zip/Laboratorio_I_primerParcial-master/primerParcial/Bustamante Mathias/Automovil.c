#include "propietarioAutomovil.h"


int devolverHorasEstadia()
{
    int horas;

    srand(time(NULL));

    horas = (rand()%24)+1;

    return horas;
}

void eAutomovil_hardCode(eAutomovil* pAutomovil)
{
    int i;

    int hardcode_IDPropietario[5]= {1,1,3,4,5};
    char hardcode_PATENTE[5][SIZE_NAME]= {"MLG 123","BZB 666", "KGB 182", "KKK 435", "ATK 077"};
    int hardcode_MARCA[5]= {1,1,2,3,0};

    for(i=0; i<5; i++)
    {
        pAutomovil[i].idAutomovil=i+1;
        pAutomovil[i].idPropietarioAutomovil=hardcode_IDPropietario[i];
        strcpy(pAutomovil[i].patente, hardcode_PATENTE[i]);
        pAutomovil[i].marca=hardcode_MARCA[i];
        pAutomovil[i].isEmpty=OCUPADO;
    }
}

void eAutomovil_inicializar(eAutomovil* pAutomovil, int SIZEARRAY)
{
    int i;
    for(i=0; i<SIZEARRAY; i++)
    {
        pAutomovil[i].isEmpty=LIBRE;
    }
}

int eAutomovil_buscarEspacioLibre(eAutomovil* pAutomovil, int SIZEARRAY)
{
    int indiceVectorLibre=-1;
    int i;

    for(i=0; i<SIZEARRAY; i++)
    {
        if(pAutomovil[i].isEmpty==LIBRE)
        {
            indiceVectorLibre=i;
            break;
        }

    }

    return indiceVectorLibre;
}

int cantidadAutomoviles(eAutomovil* pAutomovil, int SIZEARRAY)
{
    int cantidadArray=0;
    int i;

    for(i=0; i<SIZEARRAY; i++)
    {
        if(pAutomovil[i].isEmpty==OCUPADO)
        {
            cantidadArray++;
        }
    }
    return cantidadArray;
}
