#include "Propietario.h"
#include "Automovil.h"
#include "lib_gets.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#define ARRAY_RECAUDO 1
typedef struct
{
    int recaudoTotal;
    int recaudoOtros;
    int recaudoAlphaRomeo;
    int recaudoFerrari;
    int recaudoAudi;

}eRecaudo;

void eRecaudo_inicializar(eRecaudo* pRecaudo);

int calcularImporte(int MARCA, eRecaudo* pRecaudo);

int calcularImporte_horasEstadia(int MARCA, int horasEstadia);

void bajaAutomovilEstacionadoPropietario(eAutomovil* pAutomovil, int SIZEARRAY, int IDPropietario);

int bajaPropietario(ePropietario* pPropietario, eAutomovil* pAutomovil, eRecaudo* pRecaudo, int SIZEARRAY);

eAutomovil getAutomovil(ePropietario* pPropietario, int SIZEARRAY);

int altaAutomovil(eAutomovil* pAutomovil,ePropietario* pPropietario, int SIZEARRAY);

void listarAutomoviles(eAutomovil* pAutomovil, ePropietario* pPropietario, int SIZEARRAY);

void imprimirTicket(eAutomovil* pAutomovil, ePropietario* pPropietario, eRecaudo* pRecaudo, int idAutomovil, int SIZEARRAY);

int egresoAutomovil(eAutomovil* pAutomovil, ePropietario* pPropietario, eRecaudo* pRecaudo, int SIZEARRAY);

void recaudoTotal(eRecaudo* pRecaudo);

void recaudoMarcas(eRecaudo* pRecaudo);

int infoPropietario_Automoviles(eAutomovil* pAutomovil, ePropietario* pPropietario, int SIZEARRAY);

int infoPropietario_AutomovilesAudi(eAutomovil* pAutomovil, ePropietario* pPropietario, int SIZEARRAY);

void ordenarPatente(eAutomovil* pAutomovil, int SIZEARRAY);

int listarAutomoviles_patente(eAutomovil* pAutomovil, ePropietario* pPropietario, int SIZEARRAY);
