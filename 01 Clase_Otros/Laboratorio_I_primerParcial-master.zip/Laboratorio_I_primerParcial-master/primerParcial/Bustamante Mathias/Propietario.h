#define ARRAYSIZE 20
#define SIZE_NAME 64
#define SIZE_DIRECCION 64
#define SIZE_TARJETACREDITO 20

#define LIBRE 0
#define OCUPADO 1
/**ESTRUCTURA PROPIETARIO*/

typedef struct
{
    int idPropietario;
    int isEmpty;
    char name[SIZE_NAME];
    char direccion[SIZE_DIRECCION];
    char tarjetaCredito[SIZE_TARJETACREDITO];

} ePropietario;

void ePropietario_hardCode(ePropietario* pPropietario);

void ePropietario_inicializar(ePropietario* pPropietario, int SIZEARRAY);

int ePropietario_buscarEspacioLibre(ePropietario* pPropietario, int SIZEARRAY);

ePropietario getPropietario();

int altaPropietario(ePropietario* pPropietario, int SIZEARRAY);

int cantidadPropietarioTrueFalse(ePropietario* pPropietario, int SIZEARRAY);

int modificarPropietario(ePropietario* pPropietario, int SIZEARRAY);

void ordenarAlfabeticamente(ePropietario* pPropietario, int SIZEARRAY);

int listarPropietarioName(ePropietario* pPropietario, int SIZEARRAY);

void ordenarID(ePropietario* pPropietario, int SIZEARRAY);

void listarPropietarios(ePropietario* pPropietario, int SIZEARRAY);
