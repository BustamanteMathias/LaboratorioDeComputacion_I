#define ARRAYSIZE 20
#define SIZE_PATENTE 10
#define OTRO 0
#define ALPHA_ROMEO 1
#define FERRARI 2
#define AUDI 3


/**ESTRUCTURA PROPIETARIO*/

typedef struct
{
    char patente[SIZE_PATENTE];
    int marca;
    int idPropietarioAutomovil;
    int idAutomovil;
    int isEmpty;
} eAutomovil;

int devolverHorasEstadia();

void eAutomovil_hardCode(eAutomovil* pAutomovil);

void eAutomovil_inicializar(eAutomovil* pAutomovil, int SIZEARRAY);

int eAutomovil_buscarEspacioLibre(eAutomovil* pAutomovil, int SIZEARRAY);

int cantidadAutomoviles(eAutomovil* pAutomovil, int SIZEARRAY);
